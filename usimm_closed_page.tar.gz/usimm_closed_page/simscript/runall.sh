
###########################################################################
##########  Baseline expts 
###########################################################################

#./runall.pl --w jwac --i jwac_name --f 6  --d "../output_norefresh" --o "0"

#./runall.pl --w jwac --i jwac_name --f 6  --d "../output_baseline" --o "15"

#./runall.pl --w jwac --i jwac_name --f 6  --d "../output_p7" --o "16"

#./runall.pl --w jwac --i jwac_name --f 6  --d "../output_p15" --o "17"

./runall.pl --w spec2006_hmpki --i spec2006_hmpki_name --f 18 --d "../out_closed_page_1K" --o "17"
