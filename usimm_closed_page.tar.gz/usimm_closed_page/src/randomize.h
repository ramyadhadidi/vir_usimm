#ifndef __RANDOMIZE_H__
#define __RANDOMIZE_H__
int addr_rand_init(int);
int addr_randomize(long long int *,int );
int free_rand(int);
#endif // __RANDOMIZE_H__
